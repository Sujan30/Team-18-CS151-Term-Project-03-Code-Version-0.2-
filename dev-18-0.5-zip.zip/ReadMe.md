# Name of application: 
# Version: 0.4

# who did what:
1. 
2. 
3.


# Any other instruction that users need to know:
This is compiled and run on Zulu 25 since Zulu 23 has reached EOL.
Although, it should still work on Zulu 23.

All the data needed for the app is stored locally in the "data" folder.


